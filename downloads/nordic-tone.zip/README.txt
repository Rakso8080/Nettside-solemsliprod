Dette er ein placeholder-fil for Nordic Tone LUT.
Erstatt med ekte .cube/.drx-filer frå DaVinci Resolve.
