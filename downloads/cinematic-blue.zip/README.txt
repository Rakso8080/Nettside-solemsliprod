Dette er ein placeholder-fil for Cinematic Blue LUT.
Erstatt med ekte .cube/.drx-filer frå DaVinci Resolve.
