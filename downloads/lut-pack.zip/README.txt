Dette er ein placeholder-fil for LUT Pack (alle LUT-er).
Erstatt med ekte .cube/.drx-filer frå DaVinci Resolve.
