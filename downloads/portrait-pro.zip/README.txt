Dette er ein placeholder-fil for Portrait Pro LUT.
Erstatt med ekte .cube/.drx-filer frå DaVinci Resolve.
