Dette er ein placeholder-fil for Warm Sunset LUT.
Erstatt med ekte .cube/.drx-filer frå DaVinci Resolve.
