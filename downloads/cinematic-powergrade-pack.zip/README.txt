Dette er ein placeholder-fil for Cinematic Powergrade Pack.
Erstatt med ekte .cube/.drx-filer frå DaVinci Resolve.
