Dette er ein placeholder-fil for Moody Dark LUT.
Erstatt med ekte .cube/.drx-filer frå DaVinci Resolve.
